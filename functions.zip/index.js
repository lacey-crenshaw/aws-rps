let AWS = require('aws-sdk');
let s3 = new AWS.S3();


exports.handler = (event, context) => {
    let computerChoice,
        userChoice;
    let { choice } = event;

    switch (choice) {
        case "scissors":
            computerChoice = "rock"
            break;
        case "rock":
            computerChoice = "paper"
            break;
        case "paper":
            computerChoice = "scissors"
            break;
        default:
            context.fail("Unknown submission - Please try again.")
    }

    console.log(`You chose ${userChoice}, I chose ${computerChoice}. I win!`);
    let resultFile = `You chose ${userChoice}, I chose ${computerChoice}. I win!`
    s3.putObject({
        Body: resultFile,
        Bucket: 'laceycrenshaw',
        Key: 'laceycrenshaw/result.txt'
    }(err, data) => {
        if(err) {
            console.log('error')
        } _else: {
            console,: .log(`result.txt updated successfully`)
        },
        get else() {
            return this._else;
        },
        set else(value) {
            this._else = value;
        },
    });
};


